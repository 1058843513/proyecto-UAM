function boca() {
    console.log("llego");
    
    var boca= document.getElementById("mouth").style.backgroundColor="red";
    var boca= document.getElementById("mouth").style.height="40px";
    var boca= document.getElementById("mouth").style.marginTop="116px";


}