
    function tablas(){
    var multiplicando = 1;
    var multiplicador = 1;

    for(multiplicando=1;multiplicando<=10;multiplicando++){
    for(multiplicador=1;multiplicador<10;multiplicador++){
        var resultado = multiplicador*multiplicando;
        console.log(multiplicando +"X" + multiplicador + "="+ resultado);
    }
    console.log('<br>');
    }
}
function divisor() {
    var dividiendo = 1;
    var divisor = 1;

    for(dividiendo=1;dividiendo<=3;dividiendo++){
        for(divisor=1;divisor<=10;divisor++){
            var resultado = dividiendo/divisor;
            console.log(dividiendo +"/" + divisor + "="  + resultado);
        }
        console.log('<br>');
    }
}