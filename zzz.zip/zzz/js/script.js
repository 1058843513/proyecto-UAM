function suma() {
    var num1 = document.getElementById("num1").value;
    var numReal1=  parseInt(num1);

    var num2 = document.getElementById("num2").value;
    var numReal2=  parseInt(num2);

    var res = numReal1 + numReal2;

    console.log("resultdo : " + res);
}

function divicion() {
    var num1 = document.getElementById("num1").value;
    var numReal1=  parseInt(num1);

    var num2 = document.getElementById("num2").value;
    var numReal2=  parseInt(num2);

    var res = numReal1 / numReal2;

    console.log("resultdo : " + res);
}

function multiplicacion() {
    var num1 = document.getElementById("num1").value;
    var numReal1=  parseInt(num1);

    var num2 = document.getElementById("num2").value;
    var numReal2=  parseInt(num2);

    var res = numReal1 * numReal2;

    console.log("resultdo : " + res);
}

function resta() {
    var num1 = document.getElementById("num1").value;
    var numReal1=  parseInt(num1);

    var num2 = document.getElementById("num2").value;
    var numReal2=  parseInt(num2);

    var res = numReal1 - numReal2;

    console.log("resultdo : " + res);
}